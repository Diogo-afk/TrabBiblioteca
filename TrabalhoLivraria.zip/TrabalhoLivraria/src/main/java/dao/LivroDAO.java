package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.Conexao;
import models.Autor;
import models.Livro;
import models.StatusLivro;

public class LivroDAO {

	public boolean addBook(Livro livro) {
		boolean resultado = false;
		try {
			Connection conexao = Conexao.getConnection();
			String sqlAutor = String.format("INSERT INTO tbAutor VALUES (null,'%s');", livro.getAutor().getNome());
			PreparedStatement pst = conexao.prepareStatement(sqlAutor, Statement.RETURN_GENERATED_KEYS);
			pst.executeUpdate();
			ResultSet rs = pst.getGeneratedKeys();

			int idAutor = 0;

			if (rs.next()) {
				idAutor = rs.getInt(1);
				String sqlLivro = String.format(
						"INSERT INTO tbLivro VALUES(null, '%s', '%s', %d, '%s')", 
						livro.getNome(), livro.getDataCriacao(), idAutor, livro.getStatus());
				PreparedStatement pstLivro = conexao.prepareStatement(sqlLivro, Statement.RETURN_GENERATED_KEYS);
				pstLivro.executeUpdate();
			}

			resultado = true;
			conexao.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultado;
	}
	
	
	public ArrayList<Livro> listarLivros() {
		ArrayList<Livro> livros = new ArrayList<>();
		String SQL = "SELECT tl.id, tl.nome, tl.dataCriacao, tl.status, ta.id, ta.nome as nomeAutor"
				+ " FROM tbLivro AS tl " + " INNER JOIN tbAutor AS ta ON tl.autor = ta.id";
		
		try {
			Connection conexao = Conexao.getConnection();
			PreparedStatement pst = conexao.prepareStatement(SQL);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StatusLivro status;
				if (rs.getString("status").equals("DISPONIVEL")) {
					status = StatusLivro.DISPONIVEL;
				} else if (rs.getString("status").equals("INDISPONIVEL")) {
					status = StatusLivro.INDISPONIVEL;
				} else {
					status = StatusLivro.EMPRESTADO;
				}
				
				String idLivro = rs.getString("id");
				String nomeLivro = rs.getString("nome");
				Date dataCriacao = rs.getDate("dataCriacao");
				StatusLivro statusLivro = status;
				
				
				String idAutor = rs.getString("id");
				String nomeAutor = rs.getString("nomeAutor");
				
				Autor autor = new Autor(idAutor, nomeAutor);
				Livro livro = new Livro(idLivro, nomeLivro, autor, dataCriacao, statusLivro);
				livros.add(livro);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return livros;
	}
	
	public Livro consultarLivro(int cod) {
		Livro livro = new Livro();
		try {
			Connection conexao = Conexao.getConnection();
			String SQL = String.format(
					"SELECT tl.id, tl.nome, tl.dataCriacao, tl.status, ta.id, ta.nome as nomeAutor FROM tbLivro AS tl " +
					"INNER JOIN tbAutor AS ta ON tl.autor = ta.id WHERE tl.id = %s", cod
			);
			PreparedStatement pst = conexao.prepareStatement(SQL);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				Autor autor = new Autor();
				StatusLivro status;
				livro.setId(rs.getString("id"));
				livro.setNome(rs.getString("nome"));
				livro.setDataCriacao(rs.getDate("dataCriacao"));
				if (rs.getString("status").equals("DISPONIVEL")) {
	            	status = StatusLivro.DISPONIVEL;
	            }else if (rs.getString("status").equals("INDISPONIVEL")) {
	            	status = StatusLivro.INDISPONIVEL;
	            }else {
	            	status = StatusLivro.EMPRESTADO;
	            }
				livro.setStatus(status);
				autor.setId(rs.getString("id"));
				autor.setNome(rs.getString("nomeAutor"));
				livro.setAutor(autor);
			}
			conexao.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return livro;
	}
	
	public int alterarLivro(int idLivro, String status) {
		int quantidade = 0;
		try {
			Connection conexao = Conexao.getConnection();
			String SQL = String.format("UPDATE tbLivro SET status = '%s' WHERE id = %d;", status, idLivro);
			PreparedStatement pst = conexao.prepareStatement(SQL);
			pst.executeUpdate(SQL);
			quantidade = pst.getUpdateCount();
			conexao.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return quantidade;
	}
	
	public int excluirLivro(int cod) {
		int quantidade = 0;
		try {
			Connection conexao = Conexao.getConnection();
			String SQL = String.format("DELETE FROM tbLivro WHERE id = %d;", cod);
			PreparedStatement pst = conexao.prepareStatement(SQL);
			pst.executeUpdate();
			quantidade = pst.getUpdateCount();
			conexao.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return quantidade;
	}

}
