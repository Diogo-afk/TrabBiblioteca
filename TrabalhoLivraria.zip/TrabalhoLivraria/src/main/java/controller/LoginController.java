package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UsuarioDAO;
import models.Usuario;

@WebServlet("/Login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session;
		String nomeUsuario = req.getParameter("usuario");
		String senha = req.getParameter("senha");
		
		UsuarioDAO usuarioDao =  new UsuarioDAO();
		Usuario user = usuarioDao.consultar(nomeUsuario, senha);
		
		if (user.getNome() != null) { 
			session = req.getSession(true);
			session.setAttribute("session", session);
			session.setAttribute("usuario", user.getNome());
			session.setAttribute("typo", user.getType());
			resp.sendRedirect("listagem");

		} else {
			session = req.getSession(false); 
			req.setAttribute("session", session);
			resp.sendRedirect("login.jsp"); 
		} 
	}

}
