package models;

import java.io.Serializable;
import java.util.Date;

public class Livro implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	
	private String nome;
	
	private Autor autor;
	
	private Date dataCriacao;
	
	private StatusLivro status;
	
	public Livro() {}

	public Livro(String id, String nome, Autor autor, Date dataCriacao, StatusLivro status) {
		this.id = id;
		this.nome = nome;
		this.autor = autor;
		this.dataCriacao = dataCriacao;
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Autor getAutor() {
		return autor;
	}

	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public StatusLivro getStatus() {
		return status;
	}

	public void setStatus(StatusLivro status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Livro [id=" + id + ", nome=" + nome + ", autor=" + autor + ", dataCriacao=" + dataCriacao + ", status="
				+ status + "]";
	}	
	
	

}
