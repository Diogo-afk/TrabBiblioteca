package models;

public enum StatusLivro {
	
	DISPONIVEL,
	EMPRESTADO,
	INDISPONIVEL
	
}
